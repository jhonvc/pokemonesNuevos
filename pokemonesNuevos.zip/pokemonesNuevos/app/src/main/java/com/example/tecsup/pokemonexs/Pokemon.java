package com.example.tecsup.pokemonexs;

public class Pokemon {
    int id;
    String name;
    Sprites sprites;
}
