package com.example.tecsup.pokemonexs;

public class Sprites {
    String front_default;
    String back_default;
}



